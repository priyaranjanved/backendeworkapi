import express from "express";
import Job from "../models/job.model.js";

const router = express.Router();

// ✅ GET: Search jobs for autosuggest
router.get("/search", async (req, res) => {
  try {
    const keyword = req.query.q || "";
    const jobs = await Job.find({
      $or: [
        { englishJob: new RegExp(keyword, "i") },
        { hindiJob: new RegExp(keyword, "i") }
      ]
    }).limit(10);
    res.json({ isSuccess: true, data: jobs, error: null });
  } catch (error) {
    res.json({ isSuccess: false, data: null, error: error.message });
  }
});

export default router;   // 👈 IMPORTANT
